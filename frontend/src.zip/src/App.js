import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Account from './pages/Account';
import Home from './pages/Home';
import Calendar from './pages/Calendar';
import Chat from './pages/Chat';
import StudyGroup from './pages/StudyGroup';
import Login from './pages/Login';
import Register from './pages/Register';

const App = () => {
  return (
    <>
    <BrowserRouter>
      <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/account" element={<Account />} />
              <Route path="/calendar" element={<Calendar />} />
              <Route path="/chat" element={<Chat />} />
              <Route path="/studygroup" element={<StudyGroup />} />
              <Route path="/register" element={<Register />} />
      <Route path="/login" element={<Login />} />
      </Routes>
    </BrowserRouter>
    </>
  );
};

export default App;

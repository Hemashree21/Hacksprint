import React from 'react';
import Avatar from '../assets/avatar.png';
import '../pages/Chat.css';

const Navbar = () => {
  return (
    <div className='navbar'>
      <span className="logo">Study Hub</span>
      <div className='user'>
        <img src={Avatar} alt="avatar" className='avatar'/>
        <span style={{marginTop: '1rem'}}>Demo</span>
        <button className='logout' style={{height: '1.8rem', marginTop: '0.8rem', width: '4rem'}}>logout</button>
      </div>
    </div>
  )
}

export default Navbar
import React from 'react';
import profile1 from '../assets/profile1.png';

const Message = () => {
  return (
    <div className='message owner'>
      <div className="message-info">
        <img src={profile1} alt="profile" />
        <span>just now</span>
      </div>
      <div className="message-content">
        <p>hello</p>
        <img src={profile1} alt="profile" />
      </div>
    </div>
  )
}

export default Message
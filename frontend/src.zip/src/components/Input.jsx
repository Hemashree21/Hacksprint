import React from 'react';
import attach from '../assets/attach-icon.png';
import addfile from '../assets/add-file.png';

const Input = () => {
  return (
    <div className="input">
      <input type='text' placeholder='Type something...'/>
      <div className="send">
        <img src={attach} alt="attach-icon" />
        <input type="file" style={{display: 'none'}} id="file" />
        <label htmlFor="file">
          <img src={addfile} alt="add-file" />
        </label>
        <button>Send</button>
      </div>
    </div>
  )
}

export default Input
import Scheduler from './Schedular';
import '../Scheduler/Schedular.css';


export default Scheduler;
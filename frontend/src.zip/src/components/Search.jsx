import React from 'react';
import Profile1 from '../assets/profile1.png';

const Search = () => {
  return (
    <div className='search'>
      <div className="searchform">
        <input type='text' placeholder='Find a user'/>
      </div>
      <div className="userchat">
        <img src={Profile1} alt='profile-pic' className='profile1'/>
        <div className="user-chat-info">
          <span>Jane</span>
        </div>
      </div>
    </div>
  )
}

export default Search
import Toolbar from './Toolbar';
import '../Toolbar/Toolbar.css';

export default Toolbar;
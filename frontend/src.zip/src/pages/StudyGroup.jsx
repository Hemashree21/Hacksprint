import React from 'react'
import Layout from '../components/Layout'

const StudyGroup = () => {
  return (
    <Layout>StudyGroup</Layout>
  )
}

export default StudyGroup
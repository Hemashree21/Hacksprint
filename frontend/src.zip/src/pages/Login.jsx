import React, { useState } from 'react';
import SchoolIcon from '@mui/icons-material/School';
import { auth } from '../firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';

const Login = () => {

    const [email,setEmail] = useState('');
    const [password, setPassword] = useState('');

    const login = (e) => {
        e.preventDefault();
        signInWithEmailAndPassword(auth, email, password)
        .then((userCredentials) => {
            console.log(userCredentials)
        })
        .catch((error) => {
            console.log(error);
        })
    }
  return (
    <div className='register-container'>
        <div className="register-wrapper">
            <span className="register-logo"><SchoolIcon sx={{fontSize: '5rem', mr: '1rem', verticalAlign: 'middle'}}/>Study Hub</span>
            <span className="reg-title">Login</span>
            <form onSubmit={login}>
                <input type="email" placeholder='email' value={email} onChange={(e) => setEmail(e.target.value)}/>
                <input type="password" placeholder='password' vlaue={password} onChange={(e) => setPassword(e.target.value)}/>
                <button type='submit' style={{marginTop: '1.5rem'}}>Sign In</button>
            </form>
            <p>Don't have an account?</p>
            <p id='login'>Register</p>
        </div>
    </div>
  )
}

export default Login